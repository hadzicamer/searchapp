// Import all the channels to be used by Action Cable
import "channels/search_channel";
